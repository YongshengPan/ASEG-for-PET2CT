import os.path
import sys
from pathlib import Path
import argparse
import subprocess
import csv
import nibabel as nib
import numpy as np
import glob
import SimpleITK as sitk

from totalsegmentator.map_to_binary import class_map_5_parts, class_map


def get_database(input_path, csvname, subset='train'):
    imdb = []
    with open(csvname, newline='') as csvfile:
        imdbreader = csv.DictReader(csvfile, delimiter=',', quotechar='|')
        for row in imdbreader:
            if len(imdb) == 0:
                pass
            elif os.path.join(input_path, row['Collection'], row['SubjectID'], row['Filepath']) == os.path.join(
                    input_path, imdb[-1]['Collection'], imdb[-1]['SubjectID'], imdb[-1]['Filepath']):
                row['SampleID'] = str(int(imdb[-1]['SampleID']) + 1)
            # if row['CT'] == '':
            #     continue
            print(row)
            imdb.append(row)

    return imdb

def combine_all_seg(mask_dir):
    all_class_map = list(class_map.values())
    ribs_masks = list(class_map_5_parts["class_map_part_ribs"].values())
    vertebrae_masks = list(class_map_5_parts["class_map_part_vertebrae"].values())
    vertebrae_ribs_masks = list(class_map_5_parts["class_map_part_vertebrae"].values()) + list(class_map_5_parts["class_map_part_ribs"].values())
    lung_masks = ["lung_upper_lobe_left", "lung_lower_lobe_left", "lung_upper_lobe_right",
                 "lung_middle_lobe_right", "lung_lower_lobe_right", 'trachea']

    heart_masks = ["heart_myocardium", "heart_atrium_left", "heart_ventricle_left",
                 "heart_atrium_right", "heart_ventricle_right"]

    gluteus_masks = ["gluteus_maximus_left", "gluteus_maximus_right", "gluteus_medius_left",
                 "gluteus_medius_right", "gluteus_minimus_left", "gluteus_minimus_right"]

    adrenal_gland_masks = ['adrenal_gland_left', 'adrenal_gland_right']  # 肾上腺

    kidney_masks = ['kidney_left', 'kidney_right']

    liver_masks = ['liver', ]

    iliac_masks = ['iliac_artery_left', 'iliac_artery_right', 'iliac_vena_left', 'iliac_vena_right'] # 髂骨

    muscle_masks = ['iliopsoas_left', 'iliopsoas_right', ] + gluteus_masks

    blood_vessel_masks = ['aorta', 'portal_vein_and_splenic_vein', 'pulmonary_artery', 'inferior_vena_cava', ]

    autochthon_masks = ['autochthon_left', 'autochthon_right', ]

    digestive_tissues = ['colon', 'duodenum', 'esophagus', 'gallbladder', 'stomach', 'pancreas',
                    'small_bowel', 'spleen', 'urinary_bladder']
    brain_mask = ['mask', ]

    bone_tissues = ['clavicula_left', 'clavicula_right', 'femur_left', 'femur_right', 'hip_left', 'hip_right', 'humerus_left', 'humerus_right',
                    'sacrum', 'scapula_left', 'scapula_right']  # 锁骨, 股骨, 髋骨, 肱骨, 骶骨, 肩胛(骨)


    ref_img = None
    for mask in all_class_map:
        ref_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        print(ref_path)
        if os.path.exists(ref_path):
            ref_img = nib.load(ref_path)
            break
    if ref_img is None:
        raise ValueError("All masks are not present in the directory")
    out_path = mask_dir + "/combined_{mask}.nii.gz".format(mask='category')
    combined = np.zeros(ref_img.shape, dtype=np.uint8)
    for idx, mask in enumerate(all_class_map):
        mask_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        if os.path.exists(mask_path):
            img = nib.load(mask_path).get_fdata()
            if mask in lung_masks:
                combined[img > 0.5] = 1
            elif mask in heart_masks:
                combined[img > 0.5] = 2
            elif mask in liver_masks:
                combined[img > 0.5] = 3
            elif mask in kidney_masks:
                combined[img > 0.5] = 4
            elif mask in adrenal_gland_masks:  # 肾上腺
                combined[img > 0.5] = 5
            elif mask in blood_vessel_masks:  # 血管
                combined[img > 0.5] = 6
            elif mask in muscle_masks:
                combined[img > 0.5] = 7
            elif mask in digestive_tissues:
                combined[img > 0.5] = 8
            elif mask in autochthon_masks:
                combined[img > 0.5] = 9
            elif mask in ribs_masks:
                combined[img > 0.5] = 10
            elif mask in vertebrae_masks:
                combined[img > 0.5] = 11
            elif mask in iliac_masks:  # 髂骨
                combined[img > 0.5] = 12
            elif mask in bone_tissues:
                combined[img > 0.5] = 13
            else:
                combined[img > 0.5] = 20

    nib.save(nib.Nifti1Image(combined, ref_img.affine), out_path)


def dice_value(predict, region):
    dv = (2 * np.sum(predict * region) + 1e-3) / (np.sum(predict) + np.sum(region) + 1e-3)
    return dv


def rMSE_value(predict, actual):
    dv_pred = (predict - np.mean(predict)) / (np.std(predict) + 1e-3)
    dv_actu = (actual - np.mean(actual)) / (np.std(actual) + 1e-3)
    return np.mean(np.abs(dv_pred-dv_actu))


all_structures = {1: "spleen",
2: "kidney_right",
3: "kidney_left",
4: "gallbladder",
5: "liver",
6: "stomach",
7: "aorta",
8: "inferior_vena_cava",
9: "portal_vein_and_splenic_vein",
10: "pancreas",
11: "adrenal_gland_right",
12: "adrenal_gland_left",
13: "lung_upper_lobe_left",
14: "lung_lower_lobe_left",
15: "lung_upper_lobe_right",
16: "lung_middle_lobe_right",
17: "lung_lower_lobe_right",
18: "vertebrae_L5",
19: "vertebrae_L4",
20: "vertebrae_L3",
21: "vertebrae_L2",
22: "vertebrae_L1",
23: "vertebrae_T12",
24: "vertebrae_T11",
25: "vertebrae_T10",
26: "vertebrae_T9",
27: "vertebrae_T8",
28: "vertebrae_T7",
29: "vertebrae_T6",
30: "vertebrae_T5",
31: "vertebrae_T4",
32: "vertebrae_T3",
33: "vertebrae_T2",
34: "vertebrae_T1",
35: "vertebrae_C7",
36: "vertebrae_C6",
37: "vertebrae_C5",
38: "vertebrae_C4",
39: "vertebrae_C3",
40: "vertebrae_C2",
41: "vertebrae_C1",
42: "esophagus",
43: "trachea",
44: "heart_myocardium",
45: "heart_atrium_left",
46: "heart_ventricle_left",
47: "heart_atrium_right",
48: "heart_ventricle_right",
49: "pulmonary_artery",
50: "brain",
51: "iliac_artery_left",
52: "iliac_artery_right",
53: "iliac_vena_left",
54: "iliac_vena_right",
55: "small_bowel",
56: "duodenum",
57: "colon",
58: "rib_left_1",
59: "rib_left_2",
60: "rib_left_3",
61: "rib_left_4",
62: "rib_left_5",
63: "rib_left_6",
64: "rib_left_7",
65: "rib_left_8",
66: "rib_left_9",
67: "rib_left_10",
68: "rib_left_11",
69: "rib_left_12",
70: "rib_right_1",
71: "rib_right_2",
72: "rib_right_3",
73: "rib_right_4",
74: "rib_right_5",
75: "rib_right_6",
76: "rib_right_7",
77: "rib_right_8",
78: "rib_right_9",
79: "rib_right_10",
80: "rib_right_11",
81: "rib_right_12",
82: "humerus left",
83: "humerus right",
84: "scapula_left",
85: "scapula_right",
86: "clavicula_left",
87: "clavicula_right",
88: "femur left",
89: "femur right",
90: "hip_left",
91: "hip_right",
92: "sacrum",
93: "face",
94: "gluteus_maximus_left",
95: "gluteus_maximus_right",
96: "gluteus_medius_left",
97: "gluteus_medius_right",
98: "gluteus_minimus_left",
99: "gluteus_minimus_right",
100: "autochthon_left",
101: "autochthon_right",
102: "iliopsoas_left",
103: "iliopsoas_right",
104: "urinary_bladder",
 }


if __name__ == "__main__":

    input_path = 'E:/dataset/NACdata1'
    # imdb = get_database(input_path, root_path+'/meta_all_collection.csv')
    np.set_printoptions(formatter={'float': '{: 0.4f}'.format})

    tissueID = [1, 2, 3, 4, 6, 8, 10, 11, 12]
    # result_path = 'D:/projects/GANEveryThing/outputseg/WholeXraytoCT16c4r/'
    # subpath = ["synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)/mask", "synA_credice_synB_ct_dicemslp2p_views_(0, 90)/mask", "synA_credice_synB_mslp2p_views_(0, 90)/mask"]
    # for rpath in subpath:
    #     allpath = glob.glob(os.path.join(result_path, rpath, '*/*/*/'))
    #     DiceCoeffs = []
    #     print(allpath)
    #     for ref_dir in allpath:
    #         actual_dir = ref_dir.replace(os.path.join(result_path, rpath), input_path)
    #         pseudo_dir = ref_dir
    #
    #         # ref_seg_path = os.path.join(ref_dir, 'refB_seg.nii.gz')
    #         pseudo_path = os.path.join(pseudo_dir, 'S1/synA_seg30.nii.gz')
    #         actual_path = os.path.join(actual_dir, 'S1/RS1_seg_2mm.nii.gz')
    #         actual_seg = sitk.GetArrayFromImage(sitk.ReadImage(actual_path))
    #         pseudo_seg = sitk.GetArrayFromImage(sitk.ReadImage(pseudo_path))
    #         if np.shape(actual_seg)[0] != np.shape(pseudo_seg)[0]:
    #             os.remove(pseudo_path)
    #             continue
    #         diff_error = np.abs(actual_seg - pseudo_seg)
    #         # DiceCoeff = [np.abs(np.mean(actual_seg[actual_seg == tissue])-np.mean(pseudo_seg[actual_seg == tissue])) for tissue in tissueID]
    #         DiceCoeff = [dice_value(actual_seg == tissue, pseudo_seg == tissue) for tissue in range(105)]
    #
    #         DiceCoeffs.append(DiceCoeff)
    #     print((np.nanmean(DiceCoeffs, axis=0)))
    #     print((np.nanstd(DiceCoeffs, axis=0)))


    result_path = 'D:/projects/GANEveryThing/outputseg/WholeXraytoCT4s23/'
    np.set_printoptions(formatter={'float': '{: 0.4f}'.format})
    subpath = [#["synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)/mask", "S1/synB_seg30.nii.gz"],
               ["synA_disp2p_synB_ct_dicedisp2p_views_(0, 90)/mask", "S1/synA_seg30.nii.gz"],]
    for rpath in subpath:
        allpath = glob.glob(os.path.join(result_path, rpath[0], '*/*/*/'))
        DiceCoeffs = []
        print(allpath)
        for ref_dir in allpath:
            actual_dir = ref_dir.replace(os.path.join(result_path, rpath[0]), input_path)
            pseudo_dir = ref_dir

            pseudo_path = os.path.join(pseudo_dir, rpath[1])
            actual_path = os.path.join(actual_dir, 'S1/RS1_seg_2mm.nii.gz')
            pseudo_seg = sitk.GetArrayFromImage(sitk.ReadImage(pseudo_path))
            actual_seg = sitk.GetArrayFromImage(sitk.ReadImage(actual_path))
            if np.shape(actual_seg)[0] != np.shape(pseudo_seg)[0]:
                os.remove(pseudo_path)
                continue
            diff_error = np.abs(actual_seg - pseudo_seg)
            # DiceCoeff = [np.abs(np.mean(actual_seg[actual_seg == tissue])-np.mean(pseudo_seg[actual_seg == tissue])) for tissue in tissueID]
            DiceCoeff = [dice_value(actual_seg == tissue, pseudo_seg == tissue) for tissue in range(105)]

            DiceCoeffs.append(DiceCoeff)
        print((np.nanmean(DiceCoeffs, axis=0)))
        print((np.nanstd(DiceCoeffs, axis=0)))





