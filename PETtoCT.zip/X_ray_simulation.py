import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.transform import radon, iradon
import SimpleITK as sitk


def NiiDataRead(path, as_type=np.float32):
    img = sitk.ReadImage(path)
    spacing = img.GetSpacing()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    img_it = sitk.GetArrayFromImage(img).astype(as_type)
    return img_it, spacing, origin, direction


image_3D, spacing, _, _ = NiiDataRead("G:\dataset/NACdata1/NSCLC/AMC-001/04-30-1994-PETCT Lung Cancer-74760/3.000000-CT FUSION-97864.nii.gz")
print(image_3D.shape)
depth = image_3D.shape[0]
attenuation_factor = 0.184/10 * 0.8945  # spacing[1]
image_3D = np.maximum(image_3D, -1000)
image_2D = (1+image_3D[int(depth/2), :, :, ]/1000) * 0.184# * attenuation_factor
print(np.min(image_2D), np.max(image_2D))
image_2D = np.rot90(image_2D, -2)
samplecount = [1, 2, 4, 8, 20, 60, 180, ] #1, 2, 4, 8, 16
fig, axs = plt.subplots(2, len(samplecount))

cv2.imwrite('original_%d.png', image_2D * 100)

for ind in range(len(samplecount)):
    theta = np.linspace(0., 180, samplecount[ind], endpoint=False)
    sinogram = radon(image_2D, theta=theta, circle=False)
    dx, dy = 0.5 * 180 / max(image_2D.shape), 0.5 / sinogram.shape[0]
    print(sinogram.shape)
    print(np.min(sinogram), np.max(sinogram))

    reconstruction_fbp = iradon(sinogram, theta=theta, circle=False)
    print(reconstruction_fbp.shape)
    print(np.min(reconstruction_fbp), np.max(reconstruction_fbp))

    error = reconstruction_fbp - image_2D
    metric_psnr = psnr(image_2D, reconstruction_fbp)
    metric_ssim = ssim(image_2D, reconstruction_fbp)
    print(f'FBP rms reconstruction error: {np.sqrt(np.mean(error**2)):.6g},', 'ssim:', metric_ssim, 'psnr:', metric_psnr)
    cv2.imwrite('image_reconstruction_%d.png' % samplecount[ind], reconstruction_fbp * 200)
    cv2.imwrite('sinogram_%d.png' % samplecount[ind], cv2.resize(sinogram/2, (512, 512), interpolation=cv2.INTER_NEAREST))

#绘制原始图像和对应的sinogram图
    axs[0, ind].set_title("Reconstruction")
    axs[0, ind].imshow(reconstruction_fbp*1, cmap='gray', vmin=0, vmax=0.50)

    axs[1, ind].set_title("Radon transform\n(Sinogram)")
    axs[1, ind].set_xlabel("Projection angle (degree)")
    axs[1, ind].set_ylabel("Projection position (pixel)")
    axs[1, ind].imshow(sinogram/2, #cv2.resize(sinogram/2, (512, 512), interpolation=cv2.INTER_NEAREST),
                       cmap='gray', extent=(dx, 180 + dx, -dy, sinogram.shape[0] + dy), interpolation='nearest', aspect='auto')
    # axs[ind, 2].set_title("Reconstruction\nFiltered back projection")
    # axs[ind, 2].imshow(reconstruction_fbp, cmap='gray', vmin=0, vmax=3.0)
    # axs[ind, 3].set_title("Reconstruction error\n Filtered back projection")
    # axs[ind, 3].imshow(error*1000, cmap="gray")
plt.show()


