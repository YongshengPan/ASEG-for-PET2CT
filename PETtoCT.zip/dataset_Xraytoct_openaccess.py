import os
import time
import cv2
import numpy as np
import csv
from itertools import combinations
import random
import SimpleITK as sitk
from core.dataproc_utils import resize_image_itk, rotation3d, get_aug_crops
from typing import Any, Callable, Dict, List, Optional, Tuple
from torch.utils.data import Dataset

class DataBase(Dataset):
    datapool = {}

    def __init__(self,
                 input_path,
                 side_len=(128, 224, 224),
                 center_shift=(0, 16, 0),
                 data_shape=(128, 192, 224),
                 model="once",
                 num_of_splits=2,
                 num_of_train_splits=1,
                 train_combinations=None,
                 angle_of_views=(0, 45, 90, 135),
                 submodalities=(('lose_dose'), ('CT')),
                 cycload=True,
                 run_stage='train',
                 data_normal='tanh',
                 use_augment=True,
                 aug_side=(256, 0, 0),
                 aug_stride=(32, 16, 16),
                 random_rotation=True,
                 randomcrop=(0, 1),
                 randomflip=('sk', 'flr', 'fud', 'r90')):
        self.side_len = side_len
        self.center_shift = center_shift
        self.data_shape = data_shape
        self.input_path = input_path
        self.num_of_splits = num_of_splits
        self.num_of_train_splits = num_of_train_splits
        self.cycload = cycload
        self.use_augment = use_augment
        self.run_stage = run_stage
        self.aug_side = aug_side
        self.aug_stride = aug_stride
        self.random_rotation = random_rotation
        self.randomcrop = randomcrop
        self.randomflip = randomflip
        self.submodalities = submodalities
        self.angle_of_views = angle_of_views
        self.cls_num = 2
        self.channels = {'CT': 1, 'skeleton': 5, 'ACPET': 1, 'NACPET': 1, 'bone': 1,  'Xray_views': 1, 'label': 2}
        self.group_map = {'DM': 1, 'AD': 1, 'CN': 0, 'pMCI': 1, 'sMCI': 0, 'sSCD': 0, 'pSCD': 1, 'MCI': 1, 'sSMC': 0,
                          'pSMC': 1, 'SMC': 0, 'sCN': 0, 'pCN': 0, 'ppCN': 1, 'Autism': 1, 'Control': 0}
        if model == 'cross_validation':
            self.train_combinations = list(combinations(range(num_of_splits), num_of_train_splits))
        elif model == 'once':
            if train_combinations is None:
                self.train_combinations = [list(combinations(range(num_of_splits), num_of_train_splits))[0]]
            else:
                self.train_combinations = [train_combinations]
        self.dataset = 'PET2CT'
        # self.datapool = {}
        self.input_setup()

    def get_database(self, csvname, subset='train'):
        imdb = []
        with open(csvname, newline='') as csvfile:
            imdbreader = csv.DictReader(csvfile, delimiter=',', quotechar='|')
            for row in imdbreader:
                if len(imdb) == 0:
                    pass
                elif os.path.join(self.input_path, row['Collection'], row['SubjectID'], row['Filepath']) == os.path.join(self.input_path, imdb[-1]['Collection'],  imdb[-1]['SubjectID'],  imdb[-1]['Filepath']):
                    row['SampleID'] = str(int(imdb[-1]['SampleID']) + 1)
                # print(row)
                imdb.append(row)
        return imdb

    def change_run_stage(self, stage):
        if stage == 'train':
            self.imdb = self.imdb_train
        elif stage == 'valid':
            self.imdb = self.imdb_valid
        else:
            self.imdb = self.imdb_test
        self.run_stage = stage

    def input_setup(self):
        subsitelist = ['CPTAC-LSCC', 'CPTAC-LUAD', 'CPTAC-PDA', 'CPTAC-UCEC', 'HNSCC', 'NSCLC', 'TCGA-HNSC', 'TCGA-LUAD', 'TCGA-THCA']
        trainsitelist = ['HNSCC', ]
        validsitelist = ['CPTAC-LSCC', 'CPTAC-LUAD', 'CPTAC-PDA', 'CPTAC-UCEC', 'TCGA-HNSC', 'TCGA-LUAD', 'TCGA-THCA']
        testsitelist = ['TCGA-HNSC', 'TCGA-LUAD', ]
        imdb = self.get_database(self.input_path + '/meta_all_collection.csv')
        # print(imdb)
        # imdb = pandas.read_csv(self.input_path + '/filelist.csv')
        self.imdb_train = [imitem for imitem in imdb if imitem['Collection'] in trainsitelist and len(imitem['CT']) > 6]
        self.imdb_valid = [imitem for imitem in imdb if imitem['Collection'] in validsitelist and len(imitem['CT']) > 6]
        self.imdb_test = [imitem for imitem in imdb if imitem['Collection'] in testsitelist and len(imitem['CT']) > 6]

        # print(self.imdb_train)
        # print(self.imdb_train)
        print(len(self.imdb_train))
        print(len(self.imdb_test))
        #print(self.imdb_train)
        self.imdb_train_split = [self.imdb_train, self.imdb_valid]
        self.imdb_valid_split = [self.imdb_valid, self.imdb_train]
        self.change_run_stage(self.run_stage)

    def read_images(self, in_cond, subset):
        spacing = 2.0
        processed_path = os.path.join(self.input_path, in_cond, 'S%s' % (subset[0]))
        if not os.path.exists(processed_path):
            os.mkdir(processed_path)
        if True or not os.path.exists(os.path.join(processed_path, 'RS%s_BM_%dmm.nii.gz' % (subset[0], spacing*10))):
            nameFile_CT = os.path.join(self.input_path, in_cond, subset[3])
            CTIMG = sitk.Maximum(sitk.ReadImage(nameFile_CT, outputPixelType=sitk.sitkInt16) + 1000, 0)
            # CTIMG = sitk.SmoothingRecursiveGaussian(CTIMG, sigma=[1.0, 1.0, 1.0])
            BMask = sitk.SmoothingRecursiveGaussian(CTIMG, sigma=[1.0, 1.0, 1.0])
            BMask = sitk.GrayscaleFillhole(sitk.Cast(BMask >= 100, sitk.sitkFloat32)) + sitk.Cast(BMask >= 850, sitk.sitkFloat32) + \
                    sitk.Cast(BMask >= 990, sitk.sitkFloat32) + sitk.Cast(BMask >= 1150, sitk.sitkFloat32)
            CTIMG = resize_image_itk(CTIMG, newSpacing=[spacing, spacing, spacing], newSize=[int(512 / spacing), int(512 / spacing), None])
            BMask = resize_image_itk(BMask, newSpacing=[spacing, spacing, spacing], newSize=[int(512 / spacing), int(512 / spacing), None])
            sitk.WriteImage(CTIMG-1000, os.path.join(processed_path, 'RS%s_CT_%dmm.nii.gz' % (subset[0], spacing*10)))
            sitk.WriteImage(BMask, os.path.join(processed_path, 'RS%s_BM_%dmm.nii.gz' % (subset[0], spacing*10)))
        else:
            CTIMG = sitk.ReadImage(os.path.join(processed_path, 'RS%s_CT_%dmm.nii.gz' % (subset[0], spacing*10)))+1000
            BMask = sitk.ReadImage(os.path.join(processed_path, 'RS%s_BM_%dmm.nii.gz' % (subset[0], spacing*10)))
        # print('TotalSegmentator -i "' + os.path.join(in_cond, 'RS%s_CT_%dmm.nii.gz' % (subset[0], spacing)).replace('\\', '/') + '" -o "' + os.path.join(in_cond, 'RS%s_CT_%dmm_seg' % (subset[0], spacing)).replace('\\', '/') + '" --preview')
        scan_size = CTIMG.GetSize()
        padBound = [0 if scan_size[0] >= self.side_len[2] else (self.side_len[2]-scan_size[0]+1)//2,
                    0 if scan_size[1] >= self.side_len[1] else (self.side_len[1]-scan_size[1]+1)//2,
                    0 if scan_size[2] >= self.side_len[0] else (self.side_len[0]-scan_size[2]+1)//2]
        if np.sum(padBound) > 0:
            # print(padBound)
            CTIMG = sitk.ConstantPad(CTIMG, padLowerBound=[padBound[0], padBound[1], 0], padUpperBound=[padBound[0], padBound[1], 0])
            CTIMG = sitk.MirrorPad(CTIMG, padLowerBound=[0, 0, padBound[2]], padUpperBound=[0, 0, padBound[2]])
            BMask = sitk.ConstantPad(BMask, padLowerBound=[padBound[0], padBound[1], 0], padUpperBound=[padBound[0], padBound[1], 0])
            BMask = sitk.MirrorPad(BMask, padLowerBound=[0, 0, padBound[2]], padUpperBound=[0, 0, padBound[2]])
            # print(scan.GetSize(), scan.GetDimension())
        affine = {'spacing': CTIMG.GetSpacing(), 'origin': CTIMG.GetOrigin(), 'direction': CTIMG.GetDirection(), 'size': CTIMG.GetSize(),
                  'depth': CTIMG.GetDepth(), 'dimension': CTIMG.GetDimension()}
        # # time_end = time.time()
        # # print('time cost', time_end - time_start, 's')
        # if True:
        #     evalout = sitk.GetArrayFromImage(BMask)[::-1, ::-1, :]
        #     namepath = os.path.join(self.input_path, in_cond)
        #     cv2.imwrite(namepath + "/{0}_coronal.tiff".format('BMask'),
        #                 np.uint8(np.minimum(np.maximum(evalout[:, :, -128]*64, 0), 255)))
        #     cv2.imwrite(namepath + "/{0}_sagittal.tiff".format('BMask'),
        #                 np.uint8(np.minimum(np.maximum(evalout[:, -112, :]*64, 0), 255)))
        #     cv2.imwrite(namepath + "/{0}_axial.tiff".format('BMask'),
        #                 np.uint8(np.minimum(np.maximum(evalout[-256 % np.shape(evalout)[0], :, :]*64, 0), 255)))
        # dataessamble = {'CT': CTIMG, 'Xray_views': Xray_views, 'affine': affine}
        dataessamble = {'CT': CTIMG, 'affine': affine}
        return dataessamble

    def __len__(self) -> int:
        return len(self.imdb)

    def __getitem__(self, index: int) -> Tuple[Any, Any]:
        imdb = self.imdb
        # print(self.imdb[index])
        flnm = os.path.join(imdb[index]['Collection'], imdb[index]['SubjectID'], imdb[index]['Filepath'])
        subset = [imdb[index]['SampleID'], imdb[index]['ACPET'], imdb[index]['NACPET'], imdb[index]['CT']]
        index_code = os.path.join(flnm, 'S%s' % (imdb[index]['SampleID']))
        if index_code in self.datapool:
            dataessamble = self.datapool[index_code]
        else:
            label = np.zeros(2, np.float32)
            label[random.randint(0, 1)] = 1
            dataessamble = self.read_images(flnm, subset)
            dataessamble.update({'label': label})
            if self.cycload:
                self.datapool[index_code] = dataessamble
        aug_side = self.aug_side
        aug_step = np.maximum(self.aug_stride, 1)

        image_size = dataessamble['affine']['size'][::-1]
        aug_range = [min(aug_side[dim], (image_size[dim] - self.data_shape[dim] - self.center_shift[dim]) // 2) for dim in
                 range(3)]
        aug_center = [(image_size[dim] + self.center_shift[dim] - self.data_shape[dim]) // 2 for dim in range(3)]
        if not self.use_augment: aug_model = 'center'
        self.aug_model = 'random'
        aug_crops, count_of_augs = get_aug_crops(aug_center, aug_range, aug_step, aug_count=1, aug_index=(1,), aug_model=self.aug_model)
        aug_crops = [[sX1, sY1, sZ1, sX1 + self.data_shape[0], sY1 + self.data_shape[1], sZ1 + self.data_shape[2]] for
                     sX1, sY1, sZ1 in aug_crops]
        sX = aug_crops[0][0], aug_crops[0][0] + self.data_shape[0]
        sY = aug_crops[0][1], aug_crops[0][1] + self.data_shape[1]
        sZ = aug_crops[0][2], aug_crops[0][2] + self.data_shape[2]
        # print(aug_crops)
        CTIMG = dataessamble['CT']
        Xray_views = []
        attenuation_factor = 0.184 / 10 * dataessamble['affine']['spacing'][1]
        if self.random_rotation:
            pre_angle = random.randint(-10, 10)
            CTIMG = rotation3d(CTIMG, [0, 0, pre_angle], False)
        else:
            pre_angle = 0
        for angle in self.angle_of_views:
            if angle == 'rand':
                # while angle != self.angle_of_views[0]:
                    angle = random.randint(1, 179)*1.0
            rotscan = rotation3d(CTIMG, [0, 0, angle], False)
            view = sitk.Cast(sitk.SumProjection(rotscan, projectionDimension=1) / 1000 * attenuation_factor, sitk.sitkFloat32)
            view = sitk.Expand(view, (np.array(dataessamble['affine']['size']) // np.array(view.GetSize())).tolist())
            view = rotation3d(view, [0, 0, -angle], False)
            # cv2.imwrite(namepath + "/{0}_xray.tiff".format(angle),
            #             np.squeeze(np.uint8(np.minimum(np.maximum(sitk.GetArrayFromImage(view)*30, 0), 255))))
            view = np.expand_dims(sitk.GetArrayFromImage(view), axis=-1)
            Xray_views.append(view)

        Xray_views = np.transpose(np.average(Xray_views, axis=0), axes=(-1, 0, 1, 2))
        CTimg = np.expand_dims(np.float32(sitk.GetArrayFromImage(CTIMG) / 1000.0), axis=0)
        info = {'orig_size': np.array(image_size), 'aug_crops':  np.array(aug_crops), 'affine': dataessamble['affine'],
                'flnm': index_code, 'subset': subset[0], 'count_of_augs': count_of_augs}
        datainput = {'Xray_views': Xray_views[:, sX[0]:sX[1], sY[0]:sY[1], sZ[0]:sZ[1]],
                     'CT': CTimg[:, sX[0]:sX[1], sY[0]:sY[1], sZ[0]:sZ[1]]}
        datainput['bone'] = np.int8(datainput['CT'] > 0.10) + np.float32(datainput['CT'] > 0.85) + np.float32(
            datainput['CT'] > 0.99) + np.float32(datainput['CT'] > 1.15)
        datainput['label'] = dataessamble['label']
        datainput['skeleton'] = np.float32(
            np.concatenate([datainput['bone'] == chl for chl in range(self.channels['skeleton'])], axis=0))
        return datainput, info

    def inputAB(self, index=0, aug_model='random', aug_count=1, aug_index=(1,)):
        imdb = self.imdb
        flnm = os.path.join(imdb[index]['Collection'], imdb[index]['SubjectID'], imdb[index]['Filepath'])
        subset = [imdb[index]['SampleID'], imdb[index]['ACPET'], imdb[index]['NACPET'], imdb[index]['CT']]
        # print(flnm, subset)
        # print(imdb[index])
        time_start = time.time()
        index_code = os.path.join(flnm, 'S%s' % (imdb[index]['SampleID']))
        if index_code in self.datapool:
            dataessamble = self.datapool[index_code]
        else:
            label = np.zeros(2, np.float32)
            label[random.randint(0, 1)] = 1
            dataessamble = self.read_images(flnm, subset)
            dataessamble.update({'label': label})
            if self.cycload:
                self.datapool[index_code] = dataessamble
        aug_side = self.aug_side
        aug_step = np.maximum(self.aug_stride, 1)
        time_end = time.time()
        #print('time cost', time_end - time_start, 's')
        image_size = dataessamble['affine']['size'][::-1]
        aug_range = [min(aug_side[dim], (image_size[dim] - self.data_shape[dim] - self.center_shift[dim]) // 2) for dim in range(3)]
        aug_center = [(image_size[dim] + self.center_shift[dim] - self.data_shape[dim]) // 2 for dim in range(3)]
        if not self.use_augment: aug_model = 'center'
        aug_crops, count_of_augs = get_aug_crops(aug_center, aug_range, aug_step,
                                                 aug_count=aug_count, aug_index=aug_index, aug_model=aug_model)
        aug_crops = [[sX1, sY1, sZ1, sX1 + self.data_shape[0], sY1 + self.data_shape[1], sZ1 + self.data_shape[2]] for
                     sX1, sY1, sZ1 in aug_crops]
        # print(aug_crops)
        CTIMG = dataessamble['CT']
        Xray_views = []
        attenuation_factor = 0.184 / 10 * dataessamble['affine']['spacing'][1]

        # time_start = time.time()
        if self.random_rotation:
            pre_angle = random.randint(-10, 10)
            CTIMG = rotation3d(CTIMG, [0, 0, pre_angle], False)
        else:
            pre_angle = 0
        for angle in self.angle_of_views:
            if angle == 'rand':
                # while angle != self.angle_of_views[0]:
                    angle = 90.0 #random.randint(1, 179)*1.0
            rotscan = rotation3d(CTIMG, [0, 0, angle], False)
            view = sitk.Cast(sitk.SumProjection(rotscan, projectionDimension=1) / 1000 * attenuation_factor, sitk.sitkFloat32)
            view = sitk.Expand(view, (np.array(dataessamble['affine']['size']) // np.array(view.GetSize())).tolist())
            view = rotation3d(view, [0, 0, -angle], False)
            # cv2.imwrite(namepath + "/{0}_xray.tiff".format(angle),
            #             np.squeeze(np.uint8(np.minimum(np.maximum(sitk.GetArrayFromImage(view)*30, 0), 255))))
            view = np.expand_dims(sitk.GetArrayFromImage(view), axis=-1)
            Xray_views.append(view)
        # Xray_views = np.transpose(np.concatenate(Xray_views, axis=-1), axes=(-1, 0, 1, 2))
        Xray_views = np.transpose(np.average(Xray_views, axis=0), axes=(-1, 0, 1, 2))
        # time_end = time.time()
        # print('time cost', time_end - time_start, 's')

        # time_end = time.time()
        # print('time cost', time_end - time_start, 's')
        CTimg = np.expand_dims(np.float32(sitk.GetArrayFromImage(CTIMG) / 1000.0), axis=0)
        # BMask = dataessamble['CT']
        # BMask = sitk.GrayscaleFillhole(BMask >= 100) + (BMask >= 850) + (BMask >= 990) + (BMask >= 1150)
        # BMask = sitk.GetArrayFromImage(BMask)

        info = {'orig_size': np.array(image_size), 'aug_crops': np.array(aug_crops), 'affine': dataessamble['affine'],
                'flnm': index_code, 'subset': subset[0], 'count_of_augs': count_of_augs}

        datainput = {'Xray_views': np.concatenate([Xray_views[np.newaxis, :, sX1:sX2, sY1:sY2, sZ1:sZ2]
                                                   for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)}
        datainput['CT'] = np.concatenate([
            CTimg[np.newaxis, :, sX1:sX2, sY1:sY2, sZ1:sZ2] for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)
        datainput['bone'] = np.int8(datainput['CT'] > 0.10) + np.float32(datainput['CT'] > 0.85) + np.float32(datainput['CT'] > 0.99) + np.float32(datainput['CT'] > 1.15)
        datainput['label'] = np.concatenate([dataessamble['label'][np.newaxis, :] for idx in range(aug_count)], axis=0)
        datainput['skeleton'] = np.float32(np.concatenate([datainput['bone'] == chl for chl in range(self.channels['skeleton'])], axis=1))
        # datainput['skeleton'] = np.float32(
        #     np.concatenate([np.float32(datainput['CT'] < 0.10), np.float32(datainput['CT'] > 0.10), np.float32(datainput['CT'] > 0.85), np.float32(datainput['CT'] > 0.99),
        #                     np.sqrt(np.maximum(datainput['CT'] - 1.10, 0))*4.0], axis=-1))
        # time_end = time.time()
        # print('time cost', time_end - time_start, 's')
        return datainput, info

    def save_output(self, result_path, flnm, eval_out):
        flnm, refA, refB, synA, synB = eval_out['flnm'], eval_out['refA'], eval_out['refB'], eval_out['synA'], eval_out['synB']
        affine = eval_out['affine']
        if isinstance(flnm, bytes): flnm = flnm.decode()
        if not os.path.exists(result_path + "/{0}".format(flnm)): os.makedirs(result_path + "/{0}".format(flnm))
        # print(affine)
        for ref in ['refA', 'refB', 'synA', 'synB']:
            img = np.transpose(eval_out[ref], axes=(1, 2, 3, 0))
            evalout = img[::-1, ::-1, :]
            if img is not None:
                # img = np.pad(img, ((0, 0), (80, 80), (80, 80), (0, 0), ), )
                img = sitk.GetImageFromArray(np.int16(img * 1000)-1000)
                # img = sitk.GetImageFromArray(self.ct_rgb2gray(img))
                img.SetOrigin(affine['origin'])
                img.SetSpacing(affine['spacing'])
                img.SetDirection(affine['direction'])
                # img = sitk.ConstantPad(img, padLowerBound=[64, 64, 0], padUpperBound=[64, 64, 0], constant=-1000)
                sitk.WriteImage(img, result_path + "/{0}/{1}.nii.gz".format(flnm, ref), useCompression=True)

                if np.shape(evalout)[0]<256: continue
                cv2.imwrite(result_path + "/{0}/{1}_coronal.tiff".format(flnm, ref), np.uint8(np.minimum(np.maximum(evalout[:, :, -128, 0] * 256 - 127, 0), 255)))
                cv2.imwrite(result_path + "/{0}/{1}_sagittal.tiff".format(flnm, ref), np.uint8(np.minimum(np.maximum(evalout[:, -112, :, 0] * 256 - 127, 0), 255)))
                cv2.imwrite(result_path + "/{0}/{1}_axial.tiff".format(flnm, ref), np.uint8(np.minimum(np.maximum(evalout[-256, :, :, 0] * 256 - 127, 0), 255)))
                if np.shape(evalout)[-1] > 1:
                    evalout = np.argmax(evalout, axis=-1)
                    cv2.imwrite(result_path + "/{0}/Seg_{1}_coronal.tiff".format(flnm, ref),
                                np.uint8(np.minimum(np.maximum(evalout[:, :, -128] * 64, 0), 255)))
                    cv2.imwrite(result_path + "/{0}/Seg_{1}_sagittal.tiff".format(flnm, ref),
                                np.uint8(np.minimum(np.maximum(evalout[:, -112, :] * 64, 0), 255)))
                    cv2.imwrite(result_path + "/{0}/Seg_{1}_axial.tiff".format(flnm, ref),
                                np.uint8(np.minimum(np.maximum(evalout[-256, :, :] * 64, 0), 255)))

    def read_output(self, result_path, imdb, index):
        flnm = os.path.join(imdb[index]['Collection'], imdb[index]['SubjectID'], imdb[index]['Filepath'],  'S%s' % (imdb[index]['SampleID']))
        eval_out = {'flnm': flnm, 'refA': None, 'refB': None, 'synA': None, 'synB': None}
        # print(affine)
        for ref in ['refA', 'refB', 'synA', 'synB']:
            img = sitk.ReadImage(result_path + "/{0}/{1}.nii.gz".format(flnm, ref))
            arr = sitk.GetArrayFromImage(img)
            eval_out[ref] = np.float32(arr/1000.0 + 1.0)

        return eval_out

