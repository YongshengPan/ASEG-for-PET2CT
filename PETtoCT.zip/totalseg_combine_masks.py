import os.path
import sys
from pathlib import Path
import argparse
import subprocess
import csv
import nibabel as nib
import numpy as np

from totalsegmentator.map_to_binary import class_map_5_parts, class_map


def get_database(input_path, csvname, subset='train'):
    imdb = []
    with open(csvname, newline='') as csvfile:
        imdbreader = csv.DictReader(csvfile, delimiter=',', quotechar='|')
        for row in imdbreader:
            if len(imdb) == 0:
                pass
            elif os.path.join(input_path, row['Collection'], row['SubjectID'], row['Filepath']) == os.path.join(
                    input_path, imdb[-1]['Collection'], imdb[-1]['SubjectID'], imdb[-1]['Filepath']):
                row['SampleID'] = str(int(imdb[-1]['SampleID']) + 1)
            # if row['CT'] == '':
            #     continue
            print(row)
            imdb.append(row)

    return imdb

def combine_all_seg(mask_dir):
    all_class_map = list(class_map.values())
    ribs_masks = list(class_map_5_parts["class_map_part_ribs"].values())
    vertebrae_masks = list(class_map_5_parts["class_map_part_vertebrae"].values())
    vertebrae_ribs_masks = list(class_map_5_parts["class_map_part_vertebrae"].values()) + list(class_map_5_parts["class_map_part_ribs"].values())
    lung_masks = ["lung_upper_lobe_left", "lung_lower_lobe_left", "lung_upper_lobe_right",
                 "lung_middle_lobe_right", "lung_lower_lobe_right", 'trachea']

    heart_masks = ["heart_myocardium", "heart_atrium_left", "heart_ventricle_left",
                 "heart_atrium_right", "heart_ventricle_right"]

    gluteus_masks = ["gluteus_maximus_left", "gluteus_maximus_right", "gluteus_medius_left",
                 "gluteus_medius_right", "gluteus_minimus_left", "gluteus_minimus_right"]

    adrenal_gland_masks = ['adrenal_gland_left', 'adrenal_gland_right']  # 肾上腺

    kidney_masks = ['kidney_left', 'kidney_right']

    liver_masks = ['liver', ]

    iliac_masks = ['iliac_artery_left', 'iliac_artery_right', 'iliac_vena_left', 'iliac_vena_right'] # 髂骨

    muscle_masks = ['iliopsoas_left', 'iliopsoas_right', ] + gluteus_masks

    blood_vessel_masks = ['aorta', 'portal_vein_and_splenic_vein', 'pulmonary_artery', 'inferior_vena_cava', ]

    autochthon_masks = ['autochthon_left', 'autochthon_right', ]

    digestive_tissues = ['colon', 'duodenum', 'esophagus', 'gallbladder', 'stomach', 'pancreas',
                    'small_bowel', 'spleen', 'urinary_bladder']
    brain_mask = ['mask', ]

    bone_tissues = ['clavicula_left', 'clavicula_right', 'femur_left', 'femur_right', 'hip_left', 'hip_right', 'humerus_left', 'humerus_right',
                    'sacrum', 'scapula_left', 'scapula_right']  # 锁骨, 股骨, 髋骨, 肱骨, 骶骨, 肩胛(骨)



    ref_img = None
    for mask in all_class_map:
        ref_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        print(ref_path)
        if os.path.exists(ref_path):
            ref_img = nib.load(ref_path)
            break
    if ref_img is None:
        raise ValueError("All masks are not present in the directory")
    out_path = mask_dir + "/combined_{mask}.nii.gz".format(mask='category')
    combined = np.zeros(ref_img.shape, dtype=np.uint8)
    for idx, mask in enumerate(all_class_map):
        mask_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        if os.path.exists(mask_path):
            img = nib.load(mask_path).get_fdata()
            if mask in lung_masks:
                combined[img > 0.5] = 1
            elif mask in heart_masks:
                combined[img > 0.5] = 2
            elif mask in liver_masks:
                combined[img > 0.5] = 3
            elif mask in kidney_masks:
                combined[img > 0.5] = 4
            elif mask in adrenal_gland_masks:
                combined[img > 0.5] = 5
            elif mask in blood_vessel_masks:  # 血管
                combined[img > 0.5] = 6
            elif mask in muscle_masks:
                combined[img > 0.5] = 7
            elif mask in digestive_tissues:
                combined[img > 0.5] = 8
            elif mask in autochthon_masks:
                combined[img > 0.5] = 9
            elif mask in ribs_masks:
                combined[img > 0.5] = 10
            elif mask in vertebrae_masks:
                combined[img > 0.5] = 11
            elif mask in iliac_masks:  # 髂骨
                combined[img > 0.5] = 12
            elif mask in bone_tissues:
                combined[img > 0.5] = 13
            else:
                combined[img > 0.5] = 20

    nib.save(nib.Nifti1Image(combined, ref_img.affine), out_path)


if __name__ == "__main__":
    root_path = 'E:/dataset/NACdata1'
    input_path = 'E:/dataset/NACdata1'
    imdb = get_database(input_path, root_path+'/meta_all_collection.csv')

    for db in imdb:
        mask_dir = os.path.join(input_path, db['Collection'], db['SubjectID'], db['Filepath'])
        if os.path.exists(os.path.join(mask_dir, 'RS%s_CT_%dmm_seg' % (1, 2))):
            print(mask_dir)
            combine_all_seg(os.path.join(mask_dir, 'RS%s_CT_%dmm_seg' % (1, 2)))
        if os.path.exists(os.path.join(mask_dir, 'RS%s_CT_%dmm_seg' % (2, 2))):
            print(mask_dir)
            combine_all_seg(os.path.join(mask_dir, 'RS%s_CT_%dmm_seg' % (2, 2)))

