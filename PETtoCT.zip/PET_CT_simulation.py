import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.metrics import structural_similarity as ssim
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.transform import radon, iradon
import SimpleITK as sitk


def NiiDataRead(path, as_type=np.float32):
    img = sitk.ReadImage(path)
    spacing = img.GetSpacing()
    origin = img.GetOrigin()
    direction = img.GetDirection()
    img_it = sitk.GetArrayFromImage(img).astype(as_type)
    return img_it, spacing, origin, direction


CT_3D, spacing, _, _ = NiiDataRead("G:\dataset/NACdata1/NSCLC/AMC-001/04-30-1994-PETCT Lung Cancer-74760/RS1_CT_2mm.nii.gz")
AC_3D, _, _, _ = NiiDataRead("G:\dataset/NACdata1/NSCLC/AMC-001/04-30-1994-PETCT Lung Cancer-74760/RS1_AC_2mm.nii.gz")
NAC_3D, _, _, _ = NiiDataRead("G:\dataset/NACdata1/NSCLC/AMC-001/04-30-1994-PETCT Lung Cancer-74760/RS1_NAC_2mm.nii.gz")
print(CT_3D.shape)
depth = CT_3D.shape[0]
attenuation_factor = 0.184/10 * 0.8945  # spacing[1]
CT_2D = (CT_3D[int(depth*2/3), :, :, ]/1000) * 0.184# * attenuation_factor
print(np.min(CT_2D), np.max(CT_2D))
CT_2D = np.rot90(CT_2D, -2)

AC_2D = (AC_3D[int(depth*2/3), :, :, ]/1000) * 0.184# * attenuation_factor
print(np.min(AC_2D), np.max(AC_2D))
AC_2D = np.rot90(AC_2D, -2)

NAC_2D = (NAC_3D[int(depth*2/3), :, :, ]/1000) * 0.184# * attenuation_factor
print(np.min(NAC_2D), np.max(NAC_2D))
NAC_2D = np.rot90(NAC_2D, -2)

samplecount = [1, 2, 4, 8, 20, 60, 180, ][::-1] #1, 2, 4, 8, 16

cv2.imwrite('original_%d.png', CT_2D * 100)

for ind in range(len(samplecount)):
    theta = np.linspace(0., 180, samplecount[ind], endpoint=False)
    sin_CT = radon(CT_2D, theta=theta, circle=False)
    sin_AC = radon(AC_2D, theta=theta, circle=False)
    sin_NAC = radon(NAC_2D, theta=theta, circle=False)
    dx, dy = 0.5 * 180 / max(CT_2D.shape), 0.5 / sin_CT.shape[0]

    print(sin_CT.shape)
    print(np.min(sin_CT), np.max(sin_CT))

    fbp_CT = iradon(sin_CT, theta=theta, circle=False)
    fbp_AC = iradon(sin_AC, theta=theta, circle=False)
    fbp_NAC = iradon(sin_NAC, theta=theta, circle=False)
    fbp_ACT = iradon((sin_NAC*(sin_CT/10)), theta=theta, circle=False)

    print(np.min(fbp_CT), np.max(fbp_CT))

    error = fbp_AC - fbp_NAC
    metric_psnr = psnr(AC_2D, fbp_AC, data_range=2)
    metric_ssim = ssim(AC_2D, fbp_AC)
    print(f'FBP rms reconstruction error: {np.sqrt(np.mean(error**2)):.6g},', 'ssim:', metric_ssim, 'psnr:', metric_psnr)


    #绘制原始图像和对应的sinogram图
    image_sin = [sin_CT, sin_AC, sin_NAC, (sin_NAC*(sin_CT/10))]
    image_fbp = [fbp_CT, fbp_AC, fbp_NAC, fbp_ACT]
    fig, axs = plt.subplots(2, len(image_fbp))
    for mod in range(len(image_fbp)):
        axs[0, mod].set_title("Reconstruction")
        axs[0, mod].imshow(image_fbp[mod]*1, cmap='gray', vmin=0, vmax=1.00)

        axs[1, mod].set_title("Radon transform\n(Sinogram)")
        axs[1, mod].set_xlabel("Projection angle (degree)")
        axs[1, mod].set_ylabel("Projection position (pixel)")
        axs[1, mod].imshow(image_sin[mod]/2, #cv2.resize(sinogram/2, (512, 512), interpolation=cv2.INTER_NEAREST),
                       cmap='gray', extent=(dx, 180 + dx, -dy, image_sin[mod].shape[0] + dy), interpolation='nearest', aspect='auto')
    # axs[ind, 2].set_title("Reconstruction\nFiltered back projection")
    # axs[ind, 2].imshow(reconstruction_fbp, cmap='gray', vmin=0, vmax=3.0)
    # axs[ind, 3].set_title("Reconstruction error\n Filtered back projection")
    # axs[ind, 3].imshow(error*1000, cmap="gray")
    plt.show()


