import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
import numpy as np


def extend_by_dim(krnlsz, model_type='3d', half_dim=1):
    if model_type == '2d':
        outsz = [krnlsz] * 2
    elif model_type == '3d':
        outsz = [krnlsz] * 3
    elif model_type == '2.5d':
        outsz = [krnlsz] * 2 + [(np.array(krnlsz) * 0 + 1) * half_dim]
    else:
        outsz = [krnlsz]
    return outsz


class NeuralNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28*28, 512),
            nn.InstanceNorm1d(512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.InstanceNorm1d(512),
            nn.ReLU(),
            nn.Linear(512, 10)
        )

    def forward(self, x):
        x = self.flatten(x)
        logits = self.linear_relu_stack(x)
        return logits


class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1,
            padding=1, model_type='3d', change_dimension=False,
            device=None, dtype=None):
        super(ResidualBlock, self).__init__()

        self.change_dimension = in_channels != out_channels
        self.model_type = model_type
        self.change_dimension = change_dimension
        if self.model_type == '3d':
            self.ConvBlock, self.InstanceNorm = nn.Conv3d, nn.InstanceNorm3d
        elif self.model_type == '2.5d':
            self.ConvBlock, self.InstanceNorm = nn.Conv3d, nn.InstanceNorm3d
        else:
            self.ConvBlock, self.InstanceNorm = nn.Conv2d, nn.InstanceNorm2d

        def extdim(krnlsz, halfdim=1):
            return extend_by_dim(krnlsz, model_type=model_type.lower(), half_dim=halfdim)
        self.short_cut_conv = self.ConvBlock(in_channels, out_channels, 1, extdim(stride))
        self.norm0 = self.InstanceNorm(out_channels, affine=True)
        self.conv1 = self.ConvBlock(in_channels, out_channels, extdim(kernel_size), extdim(stride), padding=extdim(padding, 0), padding_mode='reflect')
        self.norm1 = self.InstanceNorm(out_channels, affine=True)
        self.conv2 = self.ConvBlock(out_channels, out_channels, extdim(kernel_size), extdim(1), padding=extdim(padding, 0), padding_mode='reflect')
        self.norm2 = self.InstanceNorm(out_channels, affine=True)

    def forward(self, x):
        if self.change_dimension:
            short_cut_conv = self.norm0(self.short_cut_conv(x))
        else:
            short_cut_conv = x
        o_c1 = F.relu(self.norm1(self.conv1(x)))
        o_c2 = self.norm2(self.conv2(o_c1))
        out_res = F.relu(o_c2+short_cut_conv)
        return out_res


class LocalizationNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        self.flatten = nn.Flatten()
        self.feats_extraction = nn.Sequential(
            nn.Conv2d(1, 16, 7, 1, 3),
            nn.InstanceNorm2d(16),
            nn.ReLU(),
            nn.Conv2d(16, 32, 3, 1, 1),
            nn.InstanceNorm2d(32),
            nn.ReLU(),
            nn.Conv2d(32, 64, 3, 1, 1),
            nn.InstanceNorm2d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, 3, 2, 1),
            nn.InstanceNorm3d(64),
            nn.ReLU(),
            nn.Conv2d(64, 64, 3, 2, 1),
            nn.InstanceNorm3d(64),
            nn.ReLU(),
        )

        self.linear_relu_stack = nn.Sequential(
            nn.Flatten(),
            nn.Linear(7*7*64*2, 1),
            # nn.InstanceNorm1d(512),
            # nn.ReLU(),
            # nn.Linear(512, 10)
    )

    def forward(self, x):
        x = self.feats_extraction(x)
        x = torch.cat((x, torch.square(x)-torch.tensor(1.0)), 1)
        x = F.normalize(x, p=2, dim=1)
        logits = self.linear_relu_stack(x)
        return logits


class SegmentationNetwork(nn.Module):

    def __init__(self, input_shape, basedim=8, downdeepth=2, output_channel=2, model_type='3D', use_skip=True):
        super(SegmentationNetwork, self).__init__()
        self.output_channel = output_channel
        self.model_type = model_type.lower()
        self.downdeepth = downdeepth

        if self.model_type == '3d':
            self.ConvBlock, self.InstanceNorm = nn.Conv3d, nn.InstanceNorm3d
            self.max_pool, self.avg_pool = F.max_pool3d, F.avg_pool3d
        elif self.model_type == '2.5d':
            self.ConvBlock, self.InstanceNorm = nn.Conv3d, nn.InstanceNorm3d
            self.max_pool, self.avg_pool = F.max_pool3d, F.avg_pool3d
        else:
            self.ConvBlock, self.InstanceNorm = nn.Conv2d, nn.InstanceNorm2d
            self.max_pool, self.avg_pool = F.max_pool2d, F.avg_pool2d
        self.bulid_network(input_shape, basedim, downdeepth, output_channel, self.model_type)

    def extdim(self, krnlsz, halfdim=1):
        return self.extend_by_dim(krnlsz, model_type=self.model_type, half_dim=halfdim)

    def bulid_network(self, input_shape, basedim, downdeepth=2, output_channel=2, model_type='3d'):
        inchl = input_shape[0]
        insize = input_shape[1::]

        self.begin_conv = nn.Sequential(self.ConvBlock(inchl, basedim, self.extdim(7), stride=self.extdim(1), padding=self.extdim(3, 0), padding_mode='reflect'),
                                        self.InstanceNorm(basedim, affine=True),
                                        nn.ReLU())
        self.encoding_block = nn.Sequential()
        for convidx in range(0, downdeepth):
            self.encoding_block.append(
                nn.Sequential(
                    ResidualBlock(basedim * 2 ** convidx, basedim * 2 ** convidx, 3, 1, model_type=self.model_type, ),
                    self.ConvBlock(basedim * 2 ** convidx, basedim * 2 ** (convidx + 1), self.extdim(3), stride=self.extdim(2), padding=self.extdim(1, 0), padding_mode='reflect'),
                    self.InstanceNorm(basedim * 2 ** (convidx + 1), affine=True),
                    nn.ReLU()))
        trans_dim = basedim * 2 ** downdeepth
        self.trans_block = nn.Sequential(
            ResidualBlock(trans_dim, trans_dim, 3, 1, model_type=self.model_type,),
            ResidualBlock(trans_dim, trans_dim, 3, 1, model_type=self.model_type,),
        )
        self.decoding_block = nn.Sequential()
        for convidx in range(0, downdeepth):
            self.decoding_block.append(
            nn.Sequential(
                self.ConvBlock(basedim * 2 ** (convidx + 2), basedim * 2 ** convidx, self.extdim(3), stride=1, padding=self.extdim(1, 0), padding_mode='reflect'),
                self.InstanceNorm(basedim * 2 ** (convidx), affine=True),
                nn.ReLU()))
        self.end_conv = nn.Sequential(self.ConvBlock(basedim*2, basedim, self.extdim(3), stride=1, padding=self.extdim(1, 0), padding_mode='reflect'),
                                      self.InstanceNorm(basedim, affine=True),
                                      self.ConvBlock(basedim, output_channel, self.extdim(7), stride=1, padding=self.extdim(3, 0), padding_mode='reflect'),
                                      self.InstanceNorm(output_channel, affine=True)
                                      )

    def forward(self, x):
        o_c1 = self.begin_conv(x)
        feats = [o_c1, ]
        for convidx in range(0, len(self.encoding_block)):
            o_c1 = self.encoding_block[convidx](o_c1)
            feats.append(o_c1)
        o_c2 = self.trans_block(o_c1)

        for convidx in range(self.downdeepth, 0, -1):
            o_c2 = torch.concat((o_c2, feats[convidx]), dim=1)
            o_c2 = self.decoding_block[convidx - 1](o_c2)
            o_c2 = F.upsample(o_c2, scale_factor=self.extdim(2), mode="nearest")

        o_c3 = self.end_conv(torch.concat((o_c2, feats[0]), dim=1))
        prob = F.softmax(o_c3, dim=1)
        return [o_c3, prob, feats]


training_data = datasets.FashionMNIST(
    root="data",
    train=True,
    download=True,
    transform=ToTensor(),
)

# Download test data from open datasets.
test_data = datasets.FashionMNIST(
    root="data",
    train=False,
    download=True,
    transform=ToTensor(),
)


batch_size = 64

# Create data loaders.
train_dataloader = DataLoader(training_data, batch_size=batch_size)
test_dataloader = DataLoader(test_data, batch_size=batch_size)

for X, y in test_dataloader:
    print(f"Shape of X [N, C, H, W]: {X.shape}")
    print(f"Shape of y: {y.shape} {y.dtype}")
    break


# Get cpu or gpu device for training.
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using {device} device")


model = LocalizationNetwork().to(device)
print(model)
loss_fn = nn.functional.mse_loss
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)


def train(dataloader, model, loss_fn, optimizer):
    size = len(dataloader.dataset)
    model.train()
    for batch, (X, y) in enumerate(dataloader):
        X, y = X.to(device), y.to(device)/10.0
        # Compute prediction error
        pred = model(X)
        loss = loss_fn(pred, y)
        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if batch % 100 == 0:
            loss, current = loss.item(), batch * len(X)
            print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]")


def test(dataloader, model, loss_fn):
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X, y in dataloader:
            X, y = X.to(device), y.to(device)/10.0
            pred = model(X)
            test_loss += loss_fn(pred, y).item()
            correct += nn.functional.l1_loss(pred, y)
    test_loss /= num_batches
    correct /= size
    print(f"Test Error: \n Accuracy: {(100*correct):>0.2f}%, Avg loss: {test_loss:>8f} \n")


epochs = 5
for t in range(epochs):
    print(f"Epoch {t+1}\n-------------------------------")
    train(train_dataloader, model, loss_fn, optimizer)
    test(test_dataloader, model, loss_fn)
print("Done!")


