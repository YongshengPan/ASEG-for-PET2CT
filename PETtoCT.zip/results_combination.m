% result_list = arrayfun(@(s) strcat('cross_validation_',num2str(s), '.csv'), 0:14, 'UniformOutput', false);
% varname = arrayfun(@(s) num2str(s), 0:14, 'UniformOutput', false);
% imdb_result = table('Size',[0, 17],'VariableTypes',['string', repmat({'single'}, [1, 16])], 'VariableNames',['subject', 'label', varname]);
% 
% for cvid = 0:14
%     result_table = readtable(strcat('cross_validation_',num2str(cvid), '.csv'));
%     for rowid = 1:height(result_table)
%         flnm = result_table{rowid, 'flnm'};
%         label = result_table{rowid, 'labelA'};
%         prob = result_table{rowid, 'probA'}>0.5;
%         locID = find(strcmp(flnm, imdb_result{:, 'subject'}));
%         if isempty(locID)
%             imdb_result{end+1, 'subject'} = flnm;
%             imdb_result{end, 'label'} = label;
%             imdb_result{end, num2str(cvid)} = prob;
%         else
%             imdb_result{locID, num2str(cvid)} = prob;
%         end
%     end
% end
% 
% writetable(imdb_result,'result_4in6_b.csv');

for rowid = 1:height(imdb_result)
        flnm = imdb_result{rowid, 'subject'};
        label = imdb_result{rowid, 'label'};
        pred = sum(imdb_result{rowid, 3:17}>0.5)>=1;
        if pred==label
            fprintf('%s,%d,%d\n', flnm, label, pred);
        end
end






