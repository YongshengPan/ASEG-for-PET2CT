import os
import numpy as np
import csv
from itertools import combinations
import random
import SimpleITK as sitk
import time
from core.dataproc_utils import resize_image_itk, get_aug_crops, standard_normalization
import cv2
from collections import Counter


class DataBase(object):
    def __init__(self,
                 input_path,
                 side_len=(128, 224, 224),
                 center_shift=(0, 16, 0),
                 data_shape=(128, 192, 224),
                 model="once",
                 num_of_splits=2,
                 num_of_train_splits=1,
                 train_combinations=None,
                 angle_of_views=(0, 45, 90, 135),
                 submodalities=(('lose_dose'), ('CT')),
                 cycload=True,
                 data_normal='tanh',
                 use_augment=True,
                 use_synthetic_CT='',
                 aug_side=(256, 0, 0),
                 aug_stride=(32, 16, 16),
                 pre_rotation=True,
                 randomcrop=(0, 1),
                 randomflip=('sk', 'flr', 'fud', 'r90')):
        self.side_len = side_len
        self.center_shift = center_shift
        self.data_shape = data_shape
        self.input_path = input_path
        self.num_of_splits = num_of_splits
        self.num_of_train_splits = num_of_train_splits
        self.cycload = cycload
        self.use_augment = use_augment
        self.use_synthetic_CT = use_synthetic_CT
        self.aug_side = aug_side
        self.aug_stride = aug_stride
        self.pre_rotation = pre_rotation
        self.randomcrop = randomcrop
        self.randomflip = randomflip
        self.submodalities = submodalities
        self.angle_of_views = angle_of_views
        self.cls_num = 2
        self.channels = {'CT': 1, 'skeleton': 5, 'ACPET': 1, 'NACPET': 1, 'bone': 1, 'Xray': 1, 'Xray_views': len(angle_of_views),
                         'label': 2}
        self.group_map = {'DM': 1, 'AD': 1, 'CN': 0, 'pMCI': 1, 'sMCI': 0, 'sSCD': 0, 'pSCD': 1, 'MCI': 1, 'sSMC': 0,
                          'pSMC': 1, 'SMC': 0, 'sCN': 0, 'pCN': 0, 'ppCN': 1, 'Autism': 1, 'Control': 0}
        if model == 'cross_validation':
            self.train_combinations = list(combinations(range(num_of_splits), num_of_train_splits))
        elif model == 'once':
            if train_combinations is None:
                self.train_combinations = [list(combinations(range(num_of_splits), num_of_train_splits))[0]]
            else:
                self.train_combinations = [train_combinations]
        self.dataset = 'PET2CT'
        self.datapool = {}
        self.input_setup()

    def get_database(self, csvname, subset='train'):
        imdb = []
        with open(csvname, newline='') as csvfile:
            imdbreader = csv.DictReader(csvfile, delimiter=',', quotechar='|')
            for row in imdbreader:
                if len(imdb) == 0:
                    pass
                elif os.path.join(self.input_path, row['Collection'], row['SubjectID'],
                                  row['Filepath']) == os.path.join(self.input_path, imdb[-1]['Collection'],
                                                                   imdb[-1]['SubjectID'], imdb[-1]['Filepath']):
                    row['SampleID'] = str(int(imdb[-1]['SampleID']) + 1)
                imdb.append(row)
        return imdb

    def input_setup(self):
        subsitelist = ['CPTAC-LSCC', 'CPTAC-LUAD', 'CPTAC-PDA', 'CPTAC-UCEC', 'HNSCC', 'NSCLC', 'TCGA-HNSC',
                       'TCGA-LUAD', 'TCGA-THCA']
        trainsitelist = ['HNSCC', ]
        validsitelist = ['CPTAC-LSCC', 'CPTAC-LUAD', 'CPTAC-PDA', 'CPTAC-UCEC', 'TCGA-HNSC', 'TCGA-LUAD', 'TCGA-THCA']
        testsitelist = ['NSCLC', 'TCGA-HNSC', 'TCGA-LUAD', ]
        # testsitelist = ['CPTAC-LSCC', 'CPTAC-LUAD', 'CPTAC-PDA', 'CPTAC-UCEC', 'TCGA-THCA']
        imdb = self.get_database(self.input_path + '/meta_all_collection_NACPET.csv')
        imdb2 = self.get_database(self.input_path + '/meta_all_collection.csv')
        for idx in range(len(imdb)):
            if imdb[idx]['CT'] != imdb2[idx]['CT'] or imdb[idx]['NACPET'] != imdb2[idx]['NACPET'] or imdb[idx]['ACPET'] != imdb2[idx]['ACPET']:
                print(imdb[idx])
                print(imdb2[idx])
        # print(imdb)
        # imdb = pandas.read_csv(self.input_path + '/filelist.csv')
        self.imdb_train = [imitem for imitem in imdb if
                           imitem['Collection'] in trainsitelist and len(imitem['CT']) > 6 and len(
                               imitem['NACPET']) > 6]
        self.imdb_valid = [imitem for imitem in imdb if
                           imitem['Collection'] in validsitelist and len(imitem['CT']) > 6 and len(
                               imitem['NACPET']) > 6]
        self.imdb_test = [imitem for imitem in imdb if
                          imitem['Collection'] in testsitelist and len(imitem['CT']) > 6 and len(
                              imitem['NACPET']) > 6 and len(imitem['ACPET']) > 6]
        self.imdb_test2 = [imitem for imitem in imdb2 if
                          imitem['Collection'] in testsitelist and len(imitem['CT']) > 6 and len(
                              imitem['NACPET']) > 6 and len(imitem['ACPET']) > 6]
        # print(self.imdb_train)
        print(len(self.imdb_train))
        print(len(self.imdb_test))
        # print(self.imdb_train)

        # for item in [ 'PatientWeight', 'PatientSize', 'PatientAge', 'PatientSex',  'Manufacturer']:
        # for it in self.imdb_test:
        #     print(it['PatientWeight'], it['PatientSize'], it['PatientAge'], it['PatientSex'], it['Manufacturer'])
        PatientWeight = [np.nan if it['PatientWeight'] == '' else float(it['PatientWeight']) for it in self.imdb_test]
        print(np.nanmean(PatientWeight), np.nanstd(PatientWeight))
        PatientSize = [np.nan if it['PatientSize'] == '' else float(it['PatientSize']) for it in self.imdb_test]
        print(np.nanmean(PatientSize), np.nanstd(PatientSize))
        PatientAge = [np.nan if it['PatientAge'] == '' else float(it['PatientAge'][0:-1]) for it in self.imdb_test]
        print(np.nanmean(PatientAge), np.nanstd(PatientAge))
        PatientSex = [it['PatientSex'] for it in self.imdb_test]
        print(PatientSex.count('M'), PatientSex.count('F'), Counter(PatientSex))
        Manufacturer = [it['Manufacturer'] for it in self.imdb_test]
        print(Counter(Manufacturer))


        self.imdb_train_split = [self.imdb_train, self.imdb_valid]
        self.imdb_valid_split = [self.imdb_valid, self.imdb_train]

    def read_images(self, in_cond, subset):
        spacing = 2
        processed_path = os.path.join(self.input_path, in_cond, 'S%s' % (subset[0]))
        if not os.path.exists(processed_path):
            os.mkdir(processed_path)
        if True and not os.path.exists(os.path.join(processed_path, 'RS%s_AC_%dmm.nii.gz' % (subset[0], spacing))):
            nameFile_CT = os.path.join(self.input_path, in_cond, subset[3])
            CTIMG = sitk.Maximum(sitk.ReadImage(nameFile_CT, outputPixelType=sitk.sitkInt16) + 1000, 0)
            CTIMG = sitk.SmoothingRecursiveGaussian(CTIMG, sigma=[1.5, 1.5, 1.5])
            BMask = sitk.SmoothingRecursiveGaussian(CTIMG, sigma=[1.5, 1.5, 1.5])
            BMask = sitk.GrayscaleFillhole(BMask >= 100) + (BMask >= 850) + (BMask >= 990) + (BMask >= 1090)
            CTIMG = resize_image_itk(CTIMG, newSpacing=[spacing, spacing, spacing],
                                     newSize=[512 // spacing, 512 // spacing, None])
            sitk.WriteImage(CTIMG - 1000, os.path.join(processed_path, 'RS%s_CT_%dmm.nii.gz' % (subset[0], spacing)))

            resampler = sitk.ResampleImageFilter()
            resampler.SetReferenceImage(CTIMG)
            resampler.SetInterpolator(sitk.sitkNearestNeighbor)
            resampler.SetDefaultPixelValue(0)
            resampler.SetOutputPixelType(sitk.sitkFloat32)
            stasts = sitk.StatisticsImageFilter()

            BMask = resampler.Execute(BMask)
            sitk.WriteImage(BMask, os.path.join(processed_path, 'RS%s_BM_%dmm.nii.gz' % (subset[0], spacing)))

            resampler.SetInterpolator(sitk.sitkLinear)
            nameFile_NAC = os.path.join(self.input_path, in_cond, subset[2])
            NACIMG = sitk.Maximum(sitk.ReadImage(nameFile_NAC, outputPixelType=sitk.sitkFloat32), 0)
            NACIMG = resampler.Execute(NACIMG)
            NACIMG = standard_normalization(NACIMG, divide='mean', remove_tail=True)
            NACIMG = sitk.Cast(sitk.Minimum(sitk.Maximum(NACIMG * 1000.0, 0), 10000), sitk.sitkUInt16)

            # NACIMG = sitk.Sqrt(NACIMG)
            # stasts.Execute(NACIMG)
            # NACIMG = sitk.Cast(sitk.Minimum((NACIMG / stasts.GetMean()) * 100.0, 60000), sitk.sitkUInt16)
            nac_mean = np.mean(sitk.GetArrayFromImage(NACIMG))
            sitk.WriteImage(NACIMG, os.path.join(processed_path, 'RS%s_NAC_%dmm.nii.gz' % (subset[0], spacing)))

            nameFile_AC = os.path.join(self.input_path, in_cond, subset[1])
            ACIMG = sitk.Maximum(sitk.ReadImage(nameFile_AC, outputPixelType=sitk.sitkFloat32), 0)
            ACIMG = resampler.Execute(ACIMG)
            ACIMG = standard_normalization(ACIMG, divide='mean', remove_tail=True)
            ACIMG = sitk.Cast(sitk.Minimum(sitk.Maximum(ACIMG * 1000.0, 0), 10000), sitk.sitkUInt16)
            # ACIMG = sitk.Sqrt(ACIMG)
            # stasts.Execute(ACIMG)
            # ACIMG = sitk.Cast(sitk.Minimum((ACIMG / stasts.GetMean()) * 100.0, 60000), sitk.sitkUInt16)
            ac_mean = np.mean(sitk.GetArrayFromImage(ACIMG))
            print(nameFile_CT, nac_mean, ac_mean, nac_mean / ac_mean)
            sitk.WriteImage(ACIMG, os.path.join(processed_path, 'RS%s_AC_%dmm.nii.gz' % (subset[0], spacing)))

        else:
            if self.use_synthetic_CT == 'p2p':
                replace_path = 'D:\projects\GANEveryThing\outputseg\WholePETtoCT16c4r\synA_p2p_synB_ct_dicep2p_views_(0, 90)\mask'
                CTIMG = sitk.ReadImage(os.path.join(replace_path, in_cond, 'S%s' % (subset[0]), 'synA.nii.gz')) + 1000
            elif self.use_synthetic_CT == 'mslp2p':
                replace_path = 'D:\projects\GANEveryThing\outputseg\WholePETtoCT16c4r\synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)\mask'
                CTIMG = sitk.ReadImage(os.path.join(replace_path, in_cond, 'S%s' % (subset[0]), 'synA.nii.gz')) + 1000
            elif self.use_synthetic_CT == 'ct_dicemslp2p':
                replace_path = 'D:\projects\GANEveryThing\outputseg\WholePETtoCT16c4r\synA_p2p_synB_ct_dicep2p_views_(0, 90)\mask'
                CTIMG = sitk.ReadImage(os.path.join(replace_path, in_cond, 'S%s' % (subset[0]), 'synB.nii.gz')) + 1000
            elif self.use_synthetic_CT == 'credice':
                replace_path = 'D:\projects\GANEveryThing\outputseg\WholePETtoCT16c4r\synA_credice_synB_ct_dicemslp2p_views_(0, 90)\mask'
                CTIMG = sitk.ReadImage(os.path.join(replace_path, in_cond, 'S%s' % (subset[0]), 'synB.nii.gz')) + 1000
            else:
                CTIMG = sitk.ReadImage(os.path.join(processed_path, 'RS%s_CT_%dmm.nii.gz' % (subset[0], spacing))) + 1000
            ACIMG = sitk.ReadImage(os.path.join(processed_path, 'RS%s_AC_%dmm.nii.gz' % (subset[0], spacing)))
            NACIMG = sitk.ReadImage(os.path.join(processed_path, 'RS%s_NAC_%dmm.nii.gz' % (subset[0], spacing)))
        # print(os.path.join(self.input_path, in_cond, subset[3]), CTIMG.GetSize(), ACIMG.GetSize(), NACIMG.GetSize())
        # ACIMG = sitk.Cast(ACIMG * 1000.0, sitk.sitkInt16)
        # NACIMG = sitk.Cast(NACIMG * 1000.0, sitk.sitkInt16)
        scan_size = NACIMG.GetSize()
        padBound = [0 if scan_size[0] >= self.side_len[2] else (self.side_len[2] - scan_size[0] + 1) // 2,
                    0 if scan_size[1] >= self.side_len[1] else (self.side_len[1] - scan_size[1] + 1) // 2,
                    0 if scan_size[2] >= self.side_len[0] else (self.side_len[0] - scan_size[2] + 1) // 2]
        if np.sum(padBound) > 0:
            # print(padBound)
            if not self.use_synthetic_CT == '':
                pass
            else:
                CTIMG = sitk.ConstantPad(CTIMG, padLowerBound=[padBound[0], padBound[1], 0], padUpperBound=[padBound[0], padBound[1], 0])
                CTIMG = sitk.MirrorPad(CTIMG, padLowerBound=[0, 0, padBound[2]], padUpperBound=[0, 0, padBound[2]])
            ACIMG = sitk.ConstantPad(ACIMG, padLowerBound=[padBound[0], padBound[1], 0],
                                     padUpperBound=[padBound[0], padBound[1], 0])
            ACIMG = sitk.MirrorPad(ACIMG, padLowerBound=[0, 0, padBound[2]], padUpperBound=[0, 0, padBound[2]])
            NACIMG = sitk.ConstantPad(NACIMG, padLowerBound=[padBound[0], padBound[1], 0],
                                      padUpperBound=[padBound[0], padBound[1], 0])
            NACIMG = sitk.MirrorPad(NACIMG, padLowerBound=[0, 0, padBound[2]], padUpperBound=[0, 0, padBound[2]])
            # print(scan.GetSize(), scan.GetDimension())
        affine = {'spacing': NACIMG.GetSpacing(), 'origin': NACIMG.GetOrigin(), 'direction': NACIMG.GetDirection(),
                  'size': NACIMG.GetSize(),
                  'depth': NACIMG.GetDepth(), 'dimension': NACIMG.GetDimension()}
        attenuation_factor = 0.184 / 10 * affine['spacing'][1]

        # bone_mask = sitk.BinaryMorphologicalClosing(CTIMG > 1100, kernelRadius=[3, 3, 3])
        CTIMG = sitk.GetArrayFromImage(CTIMG)
        ACIMG = sitk.GetArrayFromImage(ACIMG)
        NACIMG = sitk.GetArrayFromImage(NACIMG)

        # time_end = time.time()
        # print('time cost', time_end - time_start, 's')
        dataessamble = {'CT': CTIMG, 'ACPET': ACIMG, 'NACPET': NACIMG, 'affine': affine}
        for ref in ['ACPET', 'NACPET']:
            evalout = dataessamble[ref][::-1, ::-1, :]
            # namepath = os.path.join(self.input_path, in_cond, )
            cv2.imwrite(processed_path + "/{0}_coronal.tiff".format(ref), cv2.applyColorMap(
                        np.uint8(np.minimum(np.maximum(evalout[:, :, -128] // 8, 0), 255)), cv2.COLORMAP_JET))
            cv2.imwrite(processed_path + "/{0}_sagittal.tiff".format(ref), cv2.applyColorMap(
                        np.uint8(np.minimum(np.maximum(evalout[:, -112, :] // 8, 0), 255)), cv2.COLORMAP_JET))
            cv2.imwrite(processed_path + "/{0}_axial.tiff".format(ref), cv2.applyColorMap(
                        np.uint8(np.minimum(np.maximum(evalout[-256 % np.shape(evalout)[0], :, :] // 8, 0), 255)), cv2.COLORMAP_JET))

        return dataessamble

    def inputAB(self, imdb=None, split=0, index=0, model='train', aug_model='random', aug_count=1, aug_index=(1,)):
        if imdb is None:
            imdb = self.imdb_train_split[split] if model == 'train' else self.imdb_valid_split[split]
        flnm = os.path.join(imdb[index]['Collection'], imdb[index]['SubjectID'], imdb[index]['Filepath'])
        subset = [imdb[index]['SampleID'], imdb[index]['ACPET'], imdb[index]['NACPET'], imdb[index]['CT']]
        # print(flnm, subset)
        # print(imdb[index])
        index_code = os.path.join(flnm, 'S%s' % (imdb[index]['SampleID']))
        if index_code in self.datapool:
            dataessamble = self.datapool[index_code]
        else:
            label = np.zeros(2, np.float32)
            label[random.randint(0, 1)] = 1
            dataessamble = self.read_images(flnm, subset)
            dataessamble.update({'label': label})
            if self.cycload:
                self.datapool[index_code] = dataessamble
        aug_side = self.aug_side
        aug_step = np.maximum(self.aug_stride, 1)

        image_size = dataessamble['affine']['size'][::-1]
        aug_range = [min(aug_side[dim], (image_size[dim] - self.data_shape[dim] - self.center_shift[dim]) // 2) for dim
                     in range(3)]
        aug_center = [(image_size[dim] + self.center_shift[dim] - self.data_shape[dim]) // 2 for dim in range(3)]
        if not self.use_augment: aug_model = 'center'
        aug_crops, count_of_augs = get_aug_crops(aug_center, aug_range, aug_step,
                                                 aug_count=aug_count, aug_index=aug_index, aug_model=aug_model)

        aug_crops = [[sX1, sY1, sZ1, sX1 + self.data_shape[0], sY1 + self.data_shape[1], sZ1 + self.data_shape[2]] for
                     sX1, sY1, sZ1 in aug_crops]
        # print(aug_crops)
        time_start = time.time()
        datainput = {'orig_size': image_size, 'aug_crops': aug_crops, 'affine': [dataessamble['affine']],
                     'count_of_augs': [count_of_augs], 'flnm': [index_code], 'subset': [subset[0]]}
        CT, ACPET, NACPET = np.float32(dataessamble['CT']) / 1000.0, np.float32(
            dataessamble['ACPET']) / 1000.0, np.float32(dataessamble['NACPET']) / 1000.0
        XRAY = np.float32(np.mean(CT, axis=1, keepdims=True) + np.mean(CT, axis=2, keepdims=True))
        datainput['ACPET'] = np.concatenate([
            ACPET[np.newaxis, np.newaxis, sX1:sX2, sY1:sY2, sZ1:sZ2] for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)
        datainput['NACPET'] = np.concatenate([
            NACPET[np.newaxis, np.newaxis, sX1:sX2, sY1:sY2, sZ1:sZ2] for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)
        datainput['CT'] = np.concatenate([
            CT[np.newaxis, np.newaxis, sX1:sX2, sY1:sY2, sZ1:sZ2] for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)
        datainput['Xray'] = np.concatenate([
            XRAY[np.newaxis, np.newaxis, sX1:sX2, sY1:sY2, sZ1:sZ2] for sX1, sY1, sZ1, sX2, sY2, sZ2 in aug_crops], axis=0)
        datainput['bone'] = np.float32(datainput['CT'] > 0.10) + np.float32(datainput['CT'] > 0.85) + np.float32(
            datainput['CT'] > 0.99) + np.float32(datainput['CT'] > 1.15)
        datainput['label'] = np.concatenate([dataessamble['label'][np.newaxis, :] for idx in range(aug_count)], axis=0)
        datainput['skeleton'] = np.float32(
            np.concatenate([datainput['bone'] == chl for chl in range(self.channels['skeleton'])], axis=1))

        time_end = time.time()
        # print('time cost', time_end - time_start, 's')
        return index_code, datainput

    def expand_apply_synthesis(self, inputA, syn_func):
        sinputA = inputA
        if np.ndim(sinputA) == 4:
            sinputA = sinputA[np.newaxis]
        elif np.ndim(sinputA) == 3:
            sinputA = sinputA[np.newaxis, :, :, np.newaxis]
        sfake_B = syn_func(sinputA)
        fake_B = sfake_B[0]
        return fake_B

    def save_output(self, result_path, flnm, eval_out):
        flnm, refA, refB, synA, synB = eval_out['flnm'], eval_out['refA'], eval_out['refB'], eval_out['synA'], eval_out[
            'synB']
        affine = eval_out['affine']
        result_path = os.path.join(result_path, self.use_synthetic_CT)
        if isinstance(flnm, bytes): flnm = flnm.decode()
        if not os.path.exists(result_path + "/{0}".format(flnm)): os.makedirs(result_path + "/{0}".format(flnm))
        # print(affine)
        return
        for ref in ['refA', 'refB', 'synA', 'synB']:
            img = eval_out[ref]
            if img is not None:
                # img = np.pad(img, ((0, 0), (80, 80), (80, 80), (0, 0), ), )
                # print(np.min(img), np.max(img))
                # img = sitk.GetImageFromArray(img * 1000-1000)
                img = sitk.GetImageFromArray(np.int16(img * 1000 - 1000))
                # img = sitk.GetImageFromArray(self.ct_rgb2gray(img))
                img.SetOrigin(affine['origin'])
                img.SetSpacing(affine['spacing'])
                img.SetDirection(affine['direction'])
                sitk.WriteImage(img, result_path + "/{0}/{1}.nii.gz".format(flnm, ref), useCompression=True)

                evalout = eval_out[ref][::-1, ::-1, :]
                cv2.imwrite(result_path + "/{0}/{1}_coronal.tiff".format(flnm, ref), cv2.applyColorMap(
                            np.uint8(np.minimum(np.maximum(evalout[:, :, -128, 0] * 128, 0), 255)), cv2.COLORMAP_JET))
                cv2.imwrite(result_path + "/{0}/{1}_sagittal.tiff".format(flnm, ref), cv2.applyColorMap(
                            np.uint8(np.minimum(np.maximum(evalout[:, -112, :, 0] * 128, 0), 255)), cv2.COLORMAP_JET))
                cv2.imwrite(result_path + "/{0}/{1}_axial.tiff".format(flnm, ref), cv2.applyColorMap(
                            np.uint8(np.minimum(np.maximum(evalout[-min(256, np.shape(evalout)[0]), :, :, 0] * 128, 0), 255)), cv2.COLORMAP_JET))




