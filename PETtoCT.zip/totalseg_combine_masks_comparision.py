import os.path
import sys
from pathlib import Path
import argparse
import subprocess
import csv
import nibabel as nib
import numpy as np
import glob
import SimpleITK as sitk

from totalsegmentator.map_to_binary import class_map_5_parts, class_map


def get_database(input_path, csvname, subset='train'):
    imdb = []
    with open(csvname, newline='') as csvfile:
        imdbreader = csv.DictReader(csvfile, delimiter=',', quotechar='|')
        for row in imdbreader:
            if len(imdb) == 0:
                pass
            elif os.path.join(input_path, row['Collection'], row['SubjectID'], row['Filepath']) == os.path.join(
                    input_path, imdb[-1]['Collection'], imdb[-1]['SubjectID'], imdb[-1]['Filepath']):
                row['SampleID'] = str(int(imdb[-1]['SampleID']) + 1)
            # if row['CT'] == '':
            #     continue
            print(row)
            imdb.append(row)

    return imdb

def combine_all_seg(mask_dir):
    all_class_map = list(class_map.values())
    ribs_masks = list(class_map_5_parts["class_map_part_ribs"].values())
    vertebrae_masks = list(class_map_5_parts["class_map_part_vertebrae"].values())
    vertebrae_ribs_masks = list(class_map_5_parts["class_map_part_vertebrae"].values()) + list(class_map_5_parts["class_map_part_ribs"].values())
    lung_masks = ["lung_upper_lobe_left", "lung_lower_lobe_left", "lung_upper_lobe_right",
                 "lung_middle_lobe_right", "lung_lower_lobe_right", 'trachea']

    heart_masks = ["heart_myocardium", "heart_atrium_left", "heart_ventricle_left",
                 "heart_atrium_right", "heart_ventricle_right"]

    gluteus_masks = ["gluteus_maximus_left", "gluteus_maximus_right", "gluteus_medius_left",
                 "gluteus_medius_right", "gluteus_minimus_left", "gluteus_minimus_right"]

    adrenal_gland_masks = ['adrenal_gland_left', 'adrenal_gland_right']  # 肾上腺

    kidney_masks = ['kidney_left', 'kidney_right']

    liver_masks = ['liver', ]

    iliac_masks = ['iliac_artery_left', 'iliac_artery_right', 'iliac_vena_left', 'iliac_vena_right'] # 髂骨

    muscle_masks = ['iliopsoas_left', 'iliopsoas_right', ] + gluteus_masks

    blood_vessel_masks = ['aorta', 'portal_vein_and_splenic_vein', 'pulmonary_artery', 'inferior_vena_cava', ]

    autochthon_masks = ['autochthon_left', 'autochthon_right', ]

    digestive_tissues = ['colon', 'duodenum', 'esophagus', 'gallbladder', 'stomach', 'pancreas',
                    'small_bowel', 'spleen', 'urinary_bladder']
    brain_mask = ['mask', ]

    bone_tissues = ['clavicula_left', 'clavicula_right', 'femur_left', 'femur_right', 'hip_left', 'hip_right', 'humerus_left', 'humerus_right',
                    'sacrum', 'scapula_left', 'scapula_right']  # 锁骨, 股骨, 髋骨, 肱骨, 骶骨, 肩胛(骨)



    ref_img = None
    for mask in all_class_map:
        ref_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        print(ref_path)
        if os.path.exists(ref_path):
            ref_img = nib.load(ref_path)
            break
    if ref_img is None:
        raise ValueError("All masks are not present in the directory")
    out_path = mask_dir + "/combined_{mask}.nii.gz".format(mask='category')
    combined = np.zeros(ref_img.shape, dtype=np.uint8)
    for idx, mask in enumerate(all_class_map):
        mask_path = mask_dir + "/{mask}.nii.gz".format(mask=mask)
        if os.path.exists(mask_path):
            img = nib.load(mask_path).get_fdata()
            if mask in lung_masks:
                combined[img > 0.5] = 1
            elif mask in heart_masks:
                combined[img > 0.5] = 2
            elif mask in liver_masks:
                combined[img > 0.5] = 3
            elif mask in kidney_masks:
                combined[img > 0.5] = 4
            elif mask in adrenal_gland_masks:  # 肾上腺
                combined[img > 0.5] = 5
            elif mask in blood_vessel_masks:  # 血管
                combined[img > 0.5] = 6
            elif mask in muscle_masks:
                combined[img > 0.5] = 7
            elif mask in digestive_tissues:
                combined[img > 0.5] = 8
            elif mask in autochthon_masks:
                combined[img > 0.5] = 9
            elif mask in ribs_masks:
                combined[img > 0.5] = 10
            elif mask in vertebrae_masks:
                combined[img > 0.5] = 11
            elif mask in iliac_masks:  # 髂骨
                combined[img > 0.5] = 12
            elif mask in bone_tissues:
                combined[img > 0.5] = 13
            else:
                combined[img > 0.5] = 20

    nib.save(nib.Nifti1Image(combined, ref_img.affine), out_path)


def dice_value(predict, region):
    dv = (2 * np.sum(predict * region) + 1e-3) / (np.sum(predict) + np.sum(region) + 1e-3)
    return dv


def rMSE_value(predict, actual):
    dv_pred = (predict - np.mean(predict)) / (np.std(predict) + 1e-3)
    dv_actu = (actual - np.mean(actual)) / (np.std(actual) + 1e-3)
    return np.mean(np.abs(dv_pred-dv_actu))


if __name__ == "__main__":
    root_path = 'D:/projects/GANEveryThing/outputseg/'
    input_path = 'E:/dataset/NACdata1'
    # imdb = get_database(input_path, root_path+'/meta_all_collection.csv')
    ref_path = "WholePETtoCT16c4r/synA_credice_synB_ct_dicemslp2p_views_(0, 90)/mask"
    # subpath = ["WholePETtoCT16c4r/synA_p2p_synB_ct_dicep2p_views_(0, 90)/mask", "WholePETtoCT16c4r/synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)/mask"]

    # allpath = glob.glob(os.path.join(root_path, subpath[1], 'TCGA-HNSC/*/*/*')) #+ glob.glob(os.path.join(root_path, rpath, 'TCGA-HNSC/*/*/*')) + glob.glob(os.path.join(root_path, rpath, 'TCGA-LUAD/*/*/*'))
    # for mask_dir in allpath:
    #         if os.path.exists(os.path.join(mask_dir, 'synB_seg')):
    #             print(mask_dir)
    #             combine_all_seg(os.path.join(mask_dir, 'synB_seg'))
    tissueID = [1, 2, 3, 4, 6, 8, 10, 11, 12]
    # subpath = ["WholePETtoCT16c4r/synA_p2p_synB_ct_dicep2p_views_(0, 90)/mask", "WholePETtoCT16c4r/synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)/mask"]
    # for rpath in subpath:
    #     allpath = glob.glob(os.path.join(root_path, ref_path, '*/*/*/*'))
    #     DiceCoeffs = []
    #     for ref_dir in allpath:
    #         mask_dir = ref_dir.replace(ref_path, rpath)
    #
    #         ref_seg_path = os.path.join(ref_dir, 'refB_seg', 'combined_category.nii.gz')
    #         syn_seg_path = os.path.join(mask_dir, 'synA_seg', 'combined_category.nii.gz')
    #         ref_seg = sitk.GetArrayFromImage(sitk.ReadImage(ref_seg_path))
    #         syn_seg = sitk.GetArrayFromImage(sitk.ReadImage(syn_seg_path))
    #
    #         DiceCoeff = [dice_value((ref_seg == tissue), (syn_seg == tissue)) for tissue in tissueID]
    #         DiceCoeffs.append(DiceCoeff)
    #     np.set_printoptions(formatter={'float': '{: 0.4f}'.format})
    #     print((100 * np.mean(DiceCoeffs, axis=0)))
    #     print((100 * np.std(DiceCoeffs, axis=0)))
    #
    # subpath = ["WholePETtoCT16c4r/synA_mslp2p_synB_ct_dicemslp2p_views_(0, 90)/mask", "WholePETtoCT16c4r/synA_credice_synB_ct_dicemslp2p_views_(0, 90)/mask", ]
    # for rpath in subpath:
    #     allpath = glob.glob(os.path.join(root_path, ref_path, '*/*/*/*'))
    #     DiceCoeffs = []
    #     for ref_dir in allpath:
    #         mask_dir = ref_dir.replace(ref_path, rpath)
    #
    #         ref_seg_path = os.path.join(ref_dir, 'refB_seg', 'combined_category.nii.gz')
    #         syn_seg_path = os.path.join(mask_dir, 'synB_seg', 'combined_category.nii.gz')
    #         ref_seg = sitk.GetArrayFromImage(sitk.ReadImage(ref_seg_path))
    #         syn_seg = sitk.GetArrayFromImage(sitk.ReadImage(syn_seg_path))
    #
    #         DiceCoeff = [dice_value((ref_seg == tissue), (syn_seg == tissue)) for tissue in tissueID]
    #         DiceCoeffs.append(DiceCoeff)
    #     np.set_printoptions(formatter={'float': '{: 0.4f}'.format})
    #     print((100 * np.mean(DiceCoeffs, axis=0)))
    #     print((100 * np.std(DiceCoeffs, axis=0)))

    np.set_printoptions(formatter={'float': '{: 0.4f}'.format})
    subpath = ["WholePETtoPET16c4r/synA_mslp2p_synB_mslp2p_views_(0, 90)/mask/mslp2p", "WholePETtoPET16c4r/synA_mslp2p_synB_mslp2p_views_(0, 90)/mask/ct_dicemslp2p", "WholePETtoPET16c4r/synA_mslp2p_synB_mslp2p_views_(0, 90)/mask/credice"]
    for rpath in subpath:
        allpath = glob.glob(os.path.join(root_path, ref_path, '*/*/*/*'))
        DiceCoeffs = []
        for ref_dir in allpath:
            pseudo_dir = ref_dir.replace(ref_path, rpath)
            actual_dir = ref_dir.replace(ref_path, rpath)

            ref_seg_path = os.path.join(ref_dir, 'refB_seg', 'combined_category.nii.gz')
            pseudo_path = os.path.join(pseudo_dir, 'synB.nii.gz')
            actual_path = os.path.join(actual_dir, 'refB.nii.gz')
            ref_seg = sitk.GetArrayFromImage(sitk.ReadImage(ref_seg_path))
            actual_seg = sitk.GetArrayFromImage(sitk.ReadImage(actual_path))
            pseudo_seg = sitk.GetArrayFromImage(sitk.ReadImage(pseudo_path))

            diff_error = np.abs(actual_seg - pseudo_seg)
            DiceCoeff = [np.abs(np.mean(actual_seg[ref_seg == tissue])-np.mean(pseudo_seg[ref_seg == tissue])) for tissue in tissueID]

            DiceCoeffs.append(DiceCoeff)
        print((np.nanmean(DiceCoeffs, axis=0)))
        print((np.nanstd(DiceCoeffs, axis=0)))


# [0.59016338 0.80454866 0.8064225  0.65870347 0.24531132 0.53497346
#  0.72675389 0.46686424 0.63681297 0.0705904  0.53706402 0.37099711]
# [0.83134058 0.80894047 0.82816812 0.67923191 0.25991693 0.55399049
#  0.72601618 0.48552326 0.71219114 0.20773581 0.56557695 0.3675163 ]
# [0.85333592 0.76506067 0.79568902 0.58081195 0.0310414  0.43943674
#  0.68877695 0.42586119 0.73781305 0.23609691 0.67233647 0.23300706]
# [0.86301467 0.83018642 0.8298008  0.74588588 0.23284733 0.63202873
#  0.76772747 0.5455363  0.8162675  0.33994832 0.70615334 0.50281328]

# [ 58.3427  78.8948  82.5621  66.9135  52.2346  42.9981  6.8269  50.1875
#   41.8093]
# [ 15.1010  17.3515  8.1533  23.1615  13.5928  14.9372  3.5429  13.6305
#   24.0096]
# [ 80.9732  79.2484  84.1902  67.3756  52.8566  43.9106  18.9537  52.3956
#   41.1853]
# [ 12.7978  16.8534  7.7520  20.2057  14.5903  16.3346  7.3386  13.8853
#   24.0732]
# [ 83.3995  74.4071  81.9569  60.2555  46.7028  39.2472  22.3896  64.5837
#   29.5171]
# [ 11.0429  22.1261  8.3384  22.4811  12.1780  17.0434  8.3650  9.4396
#   26.5284]
# [ 85.2598  80.6250  83.4513  75.8858  63.7778  52.3180  31.5994  69.0498
#   52.7943]
# [ 8.3351  17.6718  12.0744  12.7983  8.3497  10.7199  9.3365  6.3551
#   19.8585]




